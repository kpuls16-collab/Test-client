package dev.yourclient.stub;

import net.fabricmc.api.ClientModInitializer;

public class StubMod implements ClientModInitializer {
    @Override public void onInitializeClient() { /* intentionally empty: hooks stay dormant */ }
}
