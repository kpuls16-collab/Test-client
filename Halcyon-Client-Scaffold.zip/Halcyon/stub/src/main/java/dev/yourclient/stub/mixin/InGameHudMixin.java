package dev.yourclient.stub.mixin;

import dev.yourclient.bridge.HookBridge;
import dev.yourclient.bridge.HookDispatcher;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public class InGameHudMixin {
    // NOTE: signature of render() changes between MC versions. Adjust to your target.
    @Inject(method = "render", at = @At("TAIL"))
    private void halcyon$render(DrawContext ctx, RenderTickCounter counter, CallbackInfo ci) {
        HookDispatcher d = HookBridge.dispatcher;
        if (d == null) return;
        try { d.onRender2D(ctx, counter.getTickDelta(false)); } catch (Throwable t) { t.printStackTrace(); }
    }
}
