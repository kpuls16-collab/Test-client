package dev.yourclient.stub.mixin;

import dev.yourclient.bridge.HookBridge;
import dev.yourclient.bridge.HookDispatcher;
import net.minecraft.client.Keyboard;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Keyboard.class)
public class KeyboardMixin {
    // NOTE: onKey's signature changed in newer MC versions (KeyInput). Adjust to your target.
    @Inject(method = "onKey", at = @At("HEAD"))
    private void halcyon$key(long window, int key, int scancode, int action, int mods, CallbackInfo ci) {
        HookDispatcher d = HookBridge.dispatcher;
        if (d == null) return;
        try { d.onKey(key, action, mods); } catch (Throwable t) { t.printStackTrace(); }
    }
}
