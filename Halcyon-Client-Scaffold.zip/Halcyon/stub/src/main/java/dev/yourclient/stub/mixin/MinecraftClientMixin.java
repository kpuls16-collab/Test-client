package dev.yourclient.stub.mixin;

import dev.yourclient.bridge.HookBridge;
import dev.yourclient.bridge.HookDispatcher;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MinecraftClient.class)
public class MinecraftClientMixin {
    @Inject(method = "tick", at = @At("HEAD"))
    private void halcyon$tick(CallbackInfo ci) {
        HookDispatcher d = HookBridge.dispatcher;
        if (d == null) return;
        try { d.onTick(); } catch (Throwable t) { t.printStackTrace(); }
    }
}
