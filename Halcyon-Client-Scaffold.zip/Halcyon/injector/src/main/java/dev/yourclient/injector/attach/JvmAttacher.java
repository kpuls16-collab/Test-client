package dev.yourclient.injector.attach;

import com.sun.tools.attach.VirtualMachine;
import com.sun.tools.attach.VirtualMachineDescriptor;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public final class JvmAttacher {
    public record Target(String pid, String name) {
        @Override public String toString() { return name + "  (PID " + pid + ")"; }
    }

    public static List<Target> findGames() {
        List<Target> out = new ArrayList<>();
        for (VirtualMachineDescriptor d : VirtualMachine.list()) {
            String n = d.displayName();
            if (n.contains("KnotClient") || n.contains("net.minecraft.client.main.Main")
                    || n.toLowerCase().contains("minecraft")) {
                out.add(new Target(d.id(), n.isBlank() ? "Minecraft" : n));
            }
        }
        return out;
    }

    public static void inject(Target t, Path agentJar, Path payloadJar) throws Exception {
        VirtualMachine vm = VirtualMachine.attach(t.pid());
        try { vm.loadAgent(agentJar.toAbsolutePath().toString(), payloadJar.toAbsolutePath().toString()); }
        finally { vm.detach(); }
    }
}
