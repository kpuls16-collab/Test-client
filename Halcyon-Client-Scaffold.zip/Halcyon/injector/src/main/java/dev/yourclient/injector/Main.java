package dev.yourclient.injector;

import com.formdev.flatlaf.FlatDarkLaf;
import dev.yourclient.injector.ui.InjectorWindow;

import javax.swing.*;

public final class Main {
    public static void main(String[] args) {
        FlatDarkLaf.setup();
        SwingUtilities.invokeLater(() -> new InjectorWindow().setVisible(true));
    }
}
