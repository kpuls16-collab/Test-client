package dev.yourclient.injector.ui;

import dev.yourclient.injector.attach.JvmAttacher;
import dev.yourclient.injector.attach.JvmAttacher.Target;

import javax.swing.*;
import java.awt.*;
import java.nio.file.*;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public final class InjectorWindow extends JFrame {
    private final JComboBox<Target> targets = new JComboBox<>();
    private final JTextArea log = new JTextArea();
    private final JButton inject = new JButton("INJECT");
    private final JLabel status = new JLabel("Idle");

    public InjectorWindow() {
        super("Halcyon");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(460, 480);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel root = new JPanel(new BorderLayout(0, 14));
        root.setBorder(BorderFactory.createEmptyBorder(22, 24, 22, 24));

        JLabel title = new JLabel("Halcyon");
        title.putClientProperty("FlatLaf.style", "font: bold +14; foreground: #7C5CFF");
        JLabel sub = new JLabel("Select a running Minecraft instance");
        sub.setForeground(new Color(0x8A8CA5));
        JPanel head = new JPanel(new GridLayout(2, 1));
        head.add(title); head.add(sub);

        JButton refresh = new JButton("Refresh");
        refresh.addActionListener(e -> refresh());
        JPanel pick = new JPanel(new BorderLayout(8, 0));
        pick.add(targets, BorderLayout.CENTER);
        pick.add(refresh, BorderLayout.EAST);

        inject.putClientProperty("FlatLaf.style",
                "background: #7C5CFF; foreground: #ffffff; font: bold +3; arc: 16; borderWidth: 0; focusWidth: 0");
        inject.setPreferredSize(new Dimension(0, 52));
        inject.addActionListener(e -> doInject());

        log.setEditable(false);
        log.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        JScrollPane sp = new JScrollPane(log);

        JPanel top = new JPanel(new BorderLayout(0, 14));
        top.add(head, BorderLayout.NORTH);
        top.add(pick, BorderLayout.CENTER);
        top.add(inject, BorderLayout.SOUTH);

        root.add(top, BorderLayout.NORTH);
        root.add(sp, BorderLayout.CENTER);
        root.add(status, BorderLayout.SOUTH);
        setContentPane(root);
        refresh();
    }

    private void say(String s) {
        log.append("[" + LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")) + "] " + s + "\n");
        log.setCaretPosition(log.getDocument().getLength());
    }

    private void refresh() {
        targets.removeAllItems();
        List<Target> found = JvmAttacher.findGames();
        found.forEach(targets::addItem);
        status.setText(found.isEmpty() ? "No Minecraft found" : found.size() + " instance(s) found");
        say("Scan complete: " + found.size() + " instance(s).");
    }

    private Path sibling(String name) throws Exception {
        Path self = Paths.get(InjectorWindow.class.getProtectionDomain().getCodeSource().getLocation().toURI());
        Path dir = Files.isDirectory(self) ? self : self.getParent();
        Path p = dir.resolve(name);
        if (!Files.exists(p)) throw new IllegalStateException("Missing " + name + " next to the injector.");
        return p;
    }

    private void doInject() {
        Target t = (Target) targets.getSelectedItem();
        if (t == null) { say("Nothing selected."); return; }
        inject.setEnabled(false);
        status.setText("Injecting...");
        new SwingWorker<Void, Void>() {
            @Override protected Void doInBackground() throws Exception {
                JvmAttacher.inject(t, sibling("halcyon-agent.jar"), sibling("halcyon-payload.jar"));
                return null;
            }
            @Override protected void done() {
                try { get(); say("Injected into PID " + t.pid()); status.setText("Injected"); }
                catch (Exception ex) {
                    Throwable c = ex.getCause() != null ? ex.getCause() : ex;
                    say("FAILED: " + c); status.setText("Failed");
                }
                inject.setEnabled(true);
            }
        }.execute();
    }
}
