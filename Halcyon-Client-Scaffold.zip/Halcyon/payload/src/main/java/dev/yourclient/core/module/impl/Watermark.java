package dev.yourclient.core.module.impl;

import dev.yourclient.core.event.*;
import dev.yourclient.core.module.*;
import dev.yourclient.core.gui.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public final class Watermark extends Module {
    public Watermark() { super("Watermark", "Shows the client name on the HUD.", Category.RENDER); }

    @Subscribe
    private void onRender(Events.Render2D e) {
        DrawContext ctx = (DrawContext) e.drawContext;
        var tr = MinecraftClient.getInstance().textRenderer;
        int w = tr.getWidth("Halcyon") + 12;
        ctx.fill(4, 4, 4 + w, 18, Theme.BG);
        ctx.fill(4, 4, 6, 18, Theme.ACCENT);
        ctx.drawText(tr, "Halcyon", 10, 8, Theme.TEXT, false);
    }
}
