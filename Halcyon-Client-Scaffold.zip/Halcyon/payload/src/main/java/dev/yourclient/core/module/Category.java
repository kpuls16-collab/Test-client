package dev.yourclient.core.module;

public enum Category {
    COMBAT("Combat"), MOVEMENT("Movement"), RENDER("Render"), PLAYER("Player"), WORLD("World");
    public final String label;
    Category(String l) { label = l; }
}
