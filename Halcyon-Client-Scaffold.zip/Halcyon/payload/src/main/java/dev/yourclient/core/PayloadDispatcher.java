package dev.yourclient.core;

import dev.yourclient.bridge.HookDispatcher;
import dev.yourclient.core.event.Events;
import dev.yourclient.core.gui.ClickGui;
import net.minecraft.client.MinecraftClient;

final class PayloadDispatcher implements HookDispatcher {
    static final int GUI_KEY = 344; // GLFW_KEY_RIGHT_SHIFT

    @Override public void onTick() { Client.bus.post(new Events.Tick()); }

    @Override public void onRender2D(Object ctx, float delta) { Client.bus.post(new Events.Render2D(ctx, delta)); }

    @Override public void onKey(int key, int action, int mods) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (key == GUI_KEY && action == 1) {
            if (mc.currentScreen == null) mc.setScreen(new ClickGui());
            else if (mc.currentScreen instanceof ClickGui) mc.setScreen(null);
            return;
        }
        if (mc.currentScreen == null) Client.modules.onKey(key, action);
    }

    @Override public boolean onPacketSend(Object p)    { return Client.bus.post(new Events.Packet(p, true)).isCancelled(); }
    @Override public boolean onPacketReceive(Object p) { return Client.bus.post(new Events.Packet(p, false)).isCancelled(); }
}
