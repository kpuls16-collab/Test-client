package dev.yourclient.core.module;

import dev.yourclient.core.module.impl.Sprint;
import dev.yourclient.core.module.impl.Watermark;

import java.util.*;

public final class ModuleManager {
    private final List<Module> modules = new ArrayList<>();

    public ModuleManager() {
        add(new Sprint());
        add(new Watermark());
        // Later phases: register the rest of the 60+ modules here.
    }

    private void add(Module m) { modules.add(m); }
    public List<Module> all() { return modules; }

    public List<Module> in(Category c) {
        List<Module> out = new ArrayList<>();
        for (Module m : modules) if (m.category == c) out.add(m);
        return out;
    }

    public void onKey(int key, int action) {
        if (action != 1) return;
        for (Module m : modules) if (m.key == key) m.toggle();
    }

    public void disableAll() { for (Module m : modules) m.setEnabled(false); }
}
