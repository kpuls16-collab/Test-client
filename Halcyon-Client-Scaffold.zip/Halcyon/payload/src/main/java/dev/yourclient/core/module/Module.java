package dev.yourclient.core.module;

import dev.yourclient.core.Client;

public abstract class Module {
    public final String name, description;
    public final Category category;
    private boolean enabled;
    public int key = -1;

    protected Module(String name, String description, Category category) {
        this.name = name; this.description = description; this.category = category;
    }

    public boolean isEnabled() { return enabled; }
    public void toggle() { setEnabled(!enabled); }

    public void setEnabled(boolean on) {
        if (on == enabled) return;
        enabled = on;
        if (on) { Client.bus.register(this); onEnable(); }
        else    { Client.bus.unregister(this); onDisable(); }
    }

    protected void onEnable() {}
    /** Must restore any game state this module changed. */
    protected void onDisable() {}
}
