package dev.yourclient.core.module.impl;

import dev.yourclient.core.event.*;
import dev.yourclient.core.module.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

public final class Sprint extends Module {
    public Sprint() { super("Sprint", "Always sprint while moving forward.", Category.MOVEMENT); }

    @Subscribe
    private void onTick(Events.Tick e) {
        ClientPlayerEntity p = MinecraftClient.getInstance().player;
        if (p != null && p.forwardSpeed > 0 && !p.horizontalCollision) p.setSprinting(true);
    }
}
