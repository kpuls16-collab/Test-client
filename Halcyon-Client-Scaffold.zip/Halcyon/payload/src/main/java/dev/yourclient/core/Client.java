package dev.yourclient.core;

import dev.yourclient.bridge.HookBridge;
import dev.yourclient.core.event.EventBus;
import dev.yourclient.core.gui.ClickGui;
import dev.yourclient.core.module.ModuleManager;
import net.minecraft.client.MinecraftClient;

import java.net.URLClassLoader;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Lifecycle owner. activate() is called reflectively by the agent. */
public final class Client {
    public static EventBus bus;
    public static ModuleManager modules;
    public static ExecutorService workers;
    private static boolean active;

    private Client() {}

    public static synchronized void activate() {
        if (active) return;
        bus = new EventBus();
        modules = new ModuleManager();
        workers = Executors.newCachedThreadPool(r -> { Thread t = new Thread(r, "Halcyon-Worker"); t.setDaemon(true); return t; });
        HookBridge.dispatcher = new PayloadDispatcher();   // hooks go live
        active = true;
    }

    public static synchronized void deactivate() {
        if (!active) return;
        active = false;
        HookBridge.dispatcher = null;                      // 1. hooks dormant
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.currentScreen instanceof ClickGui) mc.setScreen(null);
        modules.disableAll();                              // 2. restore state
        workers.shutdownNow();                             // 3. threads
        bus.clear();
        bus = null; modules = null; workers = null;        // 4. drop refs

        ClassLoader cl = Client.class.getClassLoader();    // 5. release the classloader shortly after
        Thread closer = new Thread(() -> {
            try { Thread.sleep(300); ((URLClassLoader) cl).close(); } catch (Throwable ignored) {}
        }, "Halcyon-Unloader");
        closer.setDaemon(true);
        closer.start();
    }
}
