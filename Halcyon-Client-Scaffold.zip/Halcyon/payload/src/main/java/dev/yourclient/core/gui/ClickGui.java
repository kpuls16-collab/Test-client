package dev.yourclient.core.gui;

import dev.yourclient.core.Client;
import dev.yourclient.core.module.Category;
import dev.yourclient.core.module.Module;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.List;

/** Clean panel-per-category ClickGUI. Left click = toggle. Unload button at the bottom. */
public final class ClickGui extends Screen {
    private static final int PW = 120, HH = 20, RH = 16, GAP = 8, TOP = 36;

    public ClickGui() { super(Text.literal("Halcyon")); }

    @Override public boolean shouldPause() { return false; }

    private int panelX(int i) {
        int total = Category.values().length * (PW + GAP) - GAP;
        return (width - total) / 2 + i * (PW + GAP);
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        ctx.fill(0, 0, width, height, 0x88000000);
        ctx.drawCenteredTextWithShadow(textRenderer, "Halcyon", width / 2, 12, Theme.ACCENT);
        ctx.drawCenteredTextWithShadow(textRenderer, "v0.1  -  RSHIFT to close", width / 2, 22, Theme.TEXT_DIM);

        Category[] cats = Category.values();
        for (int i = 0; i < cats.length; i++) {
            int x = panelX(i), y = TOP;
            List<Module> mods = Client.modules.in(cats[i]);
            int h = HH + Math.max(1, mods.size()) * RH;
            ctx.fill(x, y, x + PW, y + h, Theme.BG);
            ctx.fill(x, y, x + PW, y + HH, Theme.HEADER);
            ctx.fill(x, y + HH - 1, x + PW, y + HH, Theme.ACCENT);
            ctx.drawText(textRenderer, cats[i].label, x + 6, y + 6, Theme.TEXT, false);

            int ry = y + HH;
            if (mods.isEmpty()) ctx.drawText(textRenderer, "(empty)", x + 6, ry + 4, Theme.TEXT_DIM, false);
            for (Module m : mods) {
                boolean hover = mx >= x && mx < x + PW && my >= ry && my < ry + RH;
                ctx.fill(x, ry, x + PW, ry + RH, hover ? Theme.ROW_HOVER : Theme.ROW);
                if (m.isEnabled()) {
                    ctx.fill(x, ry, x + 2, ry + RH, Theme.ACCENT);
                    ctx.fill(x + 2, ry, x + PW, ry + RH, Theme.ACCENT_DIM);
                }
                ctx.drawText(textRenderer, m.name, x + 8, ry + 4, m.isEnabled() ? Theme.TEXT : Theme.TEXT_DIM, false);
                ry += RH;
            }
        }

        int bx = width / 2 - 50, by = height - 30;
        boolean hov = mx >= bx && mx < bx + 100 && my >= by && my < by + 18;
        ctx.fill(bx, by, bx + 100, by + 18, hov ? Theme.DANGER : 0xCC3A2326);
        ctx.drawCenteredTextWithShadow(textRenderer, "Unload", width / 2, by + 5, Theme.TEXT);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        int bx = width / 2 - 50, by = height - 30;
        if (button == 0 && mx >= bx && mx < bx + 100 && my >= by && my < by + 18) {
            Client.deactivate();
            return true;
        }
        Category[] cats = Category.values();
        for (int i = 0; i < cats.length; i++) {
            int x = panelX(i), ry = TOP + HH;
            for (Module m : Client.modules.in(cats[i])) {
                if (button == 0 && mx >= x && mx < x + PW && my >= ry && my < ry + RH) { m.toggle(); return true; }
                ry += RH;
            }
        }
        return super.mouseClicked(mx, my, button);
    }
}
