package dev.yourclient.core.event;

public final class Events {
    private Events() {}
    public static final class Tick extends Event {}
    public static final class Render2D extends Event {
        public final Object drawContext; public final float delta;
        public Render2D(Object ctx, float delta) { this.drawContext = ctx; this.delta = delta; }
    }
    public static final class Packet extends Event {
        public final Object packet; public final boolean outgoing;
        public Packet(Object p, boolean out) { this.packet = p; this.outgoing = out; }
    }
}
