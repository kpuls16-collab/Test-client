package dev.yourclient.core.gui;

public final class Theme {
    private Theme() {}
    public static final int ACCENT     = 0xFF7C5CFF;
    public static final int ACCENT_DIM = 0x557C5CFF;
    public static final int BG         = 0xE6141520;
    public static final int HEADER     = 0xF01B1C2B;
    public static final int ROW        = 0xCC1E2033;
    public static final int ROW_HOVER  = 0xCC292C45;
    public static final int TEXT       = 0xFFE6E6F0;
    public static final int TEXT_DIM   = 0xFF8A8CA5;
    public static final int DANGER     = 0xFFE5484D;
}
