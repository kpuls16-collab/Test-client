package dev.yourclient.core.event;

import java.lang.reflect.Method;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

/** Minimal annotation-based bus. Phase 2 adds priorities + lambda listeners. */
public final class EventBus {
    private record Handler(Object target, Method method) {}
    private final Map<Class<?>, List<Handler>> handlers = new HashMap<>();

    public synchronized void register(Object o) {
        for (Method m : o.getClass().getDeclaredMethods()) {
            if (!m.isAnnotationPresent(Subscribe.class) || m.getParameterCount() != 1) continue;
            m.setAccessible(true);
            handlers.computeIfAbsent(m.getParameterTypes()[0], k -> new CopyOnWriteArrayList<>())
                    .add(new Handler(o, m));
        }
    }

    public synchronized void unregister(Object o) {
        handlers.values().forEach(l -> l.removeIf(h -> h.target == o));
    }

    public <T extends Event> T post(T e) {
        List<Handler> l = handlers.get(e.getClass());
        if (l == null) return e;
        for (Handler h : l) {
            try { h.method.invoke(h.target, e); }
            catch (Throwable t) { t.printStackTrace(); }
        }
        return e;
    }

    public synchronized void clear() { handlers.clear(); }
}
