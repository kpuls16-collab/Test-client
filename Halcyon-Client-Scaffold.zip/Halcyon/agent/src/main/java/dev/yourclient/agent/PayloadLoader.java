package dev.yourclient.agent;

import java.io.File;
import java.lang.instrument.Instrumentation;
import java.lang.reflect.Field;
import java.net.URL;
import java.net.URLClassLoader;

final class PayloadLoader {
    private static final String BRIDGE = "dev.yourclient.bridge.HookBridge";
    private static final String CLIENT = "dev.yourclient.core.Client";

    static void load(String payloadPath, Instrumentation inst) throws Exception {
        // 1. Find the game's (Knot) classloader through the stub's bridge class.
        Class<?> bridge = null;
        for (Class<?> c : inst.getAllLoadedClasses()) {
            if (c.getName().equals(BRIDGE)) { bridge = c; break; }
        }
        if (bridge == null) throw new IllegalStateException("Stub mod not loaded (put halcyon-stub in mods/).");

        Field f = bridge.getField("dispatcher");
        if (f.get(null) != null) {
            System.out.println("[Halcyon] Already active, ignoring.");
            return;
        }

        // 2. Isolated, closable loader whose parent is the game loader.
        URL url = new File(payloadPath).toURI().toURL();
        URLClassLoader loader = new URLClassLoader(new URL[]{url}, bridge.getClassLoader());

        // 3. Activate.
        Class<?> client = Class.forName(CLIENT, true, loader);
        client.getMethod("activate").invoke(null);
        System.out.println("[Halcyon] Payload activated.");
    }
}
