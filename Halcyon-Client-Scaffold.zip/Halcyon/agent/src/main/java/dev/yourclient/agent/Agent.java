package dev.yourclient.agent;

import java.lang.instrument.Instrumentation;

/** Entry point invoked by VirtualMachine.loadAgent(). args = absolute path of payload jar. */
public final class Agent {
    public static void agentmain(String args, Instrumentation inst) {
        try {
            PayloadLoader.load(args, inst);
        } catch (Throwable t) {
            System.err.println("[Halcyon] Injection failed:");
            t.printStackTrace();
        }
    }
}
