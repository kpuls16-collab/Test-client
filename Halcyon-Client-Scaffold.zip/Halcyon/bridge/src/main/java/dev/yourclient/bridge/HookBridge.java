package dev.yourclient.bridge;

/** Static holder read by the stub's Mixins. Null = dormant. */
public final class HookBridge {
    public static volatile HookDispatcher dispatcher;
    private HookBridge() {}
}
