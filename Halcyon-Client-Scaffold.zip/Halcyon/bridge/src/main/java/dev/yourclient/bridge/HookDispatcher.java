package dev.yourclient.bridge;

/** Object-typed so the bridge needs no Minecraft classes. */
public interface HookDispatcher {
    void onTick();
    void onRender2D(Object drawContext, float tickDelta);
    void onKey(int key, int action, int mods);
    /** @return true to cancel */
    boolean onPacketSend(Object packet);
    boolean onPacketReceive(Object packet);
}
