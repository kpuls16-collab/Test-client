# Halcyon (Phase 1 scaffold)

Modular utility-client architecture for **single-player / private-world** experimentation.

| Module   | What it is |
|----------|-----------|
| bridge   | Tiny shared contract (HookBridge + HookDispatcher) |
| stub     | Fabric mod with dormant Mixins - goes in `mods/` |
| payload  | Hot-loadable core: events, modules, ClickGUI (not a mod) |
| agent    | Java agent that builds the payload classloader |
| injector | Swing/FlatLaf desktop app with the Inject button |

## Setup
1. Paste matching versions from https://fabricmc.net/develop into `gradle.properties`.
2. Run `gradle build` (Gradle 8.12+), or `gradle wrapper` once and then `./gradlew build`.
3. Copy the stub jar to `mods/`; launch Minecraft.
4. Put `halcyon-injector.jar`, `halcyon-agent.jar`, `halcyon-payload.jar` in one folder; run the injector with a **JDK**.
5. Click INJECT, press RSHIFT in-game. "Unload" in the GUI tears everything down.

## Version notes
`InGameHud.render`, `Keyboard.onKey` and a few player fields change between MC versions; adjust the marked spots.
Use only in worlds you own or have permission to use it on.
